# 第三方组件与许可

BreePhone 的分发包（`BreePhone-x.y.z.dmg`）里**以静态库形式**包含了下列第三方组件。
按它们各自的许可要求，随二进制分发时需要一并提供版权声明与许可原文，
本文件与 [`licenses/`](licenses/) 就是为此准备的。

> **这两样都会被打包进 App 包内**（`Scripts/package/package-app.sh` 负责拷贝到
> `BreePhone.app/Contents/Resources/`）。放在这个私有仓库里而不是公开仓库，
> 是因为公开仓库对外只讲"这是什么工具"，不讲它是怎么搭出来的 ——
> 而许可声明的义务是**跟着二进制走**的，只要随包发出就算履行，不必挂在仓库首页。

## 组件清单

| 组件 | 版本 | 许可 | 在本应用里的作用 | 许可原文 |
|---|---|---|---|---|
| baresip | 4.11.0 | BSD-3-Clause | SIP 用户代理与媒体处理核心 | [`licenses/baresip.txt`](licenses/baresip.txt) |
| libre (re) | 4.11.0 | BSD-3-Clause | SIP / SDP / RTP 协议栈 | [`licenses/libre.txt`](licenses/libre.txt) |
| Opus | 1.6.1 | BSD-3-Clause | opus 编解码 | [`licenses/opus.txt`](licenses/opus.txt) |
| spandsp | 0.0.6 | **LGPL-2.1** | G.722 编解码（baresip 的 `g722` 模块基于它） | [`licenses/spandsp.txt`](licenses/spandsp.txt) |
| OpenSSL | 3.6.4 | Apache-2.0 | TLS 传输与摘要认证 | [`licenses/openssl.txt`](licenses/openssl.txt) |

macOS 系统框架（CoreAudio、AudioToolbox、AudioUnit、AVFoundation、Security、
SystemConfiguration）由操作系统提供，不随本应用分发。

## 版权声明

```
baresip
Copyright (C) 2020 - 2026, Baresip Foundation (https://github.com/baresip)
Copyright (c) 2010 - 2024, Alfred E. Heggestad
Copyright (c) 2010 - 2021, Richard Aas
Copyright (c) 2010 - 2021, Creytiv.com

libre (re)
Copyright (C) 2020 - 2026, Baresip Foundation (https://github.com/baresip)
Copyright (c) 2010 - 2024, Alfred E. Heggestad
Copyright (c) 2010 - 2020, Richard Aas
Copyright (c) 2010 - 2020, Creytiv.com

Opus
Copyright 2001-2023 Xiph.Org, Skype Limited, Octasic,
                   Jean-Marc Valin, Timothy B. Terriberry,
                   CSIRO, Gregory Maxwell, Mark Borgerding,
                   Erik de Castro Lopo, Mozilla, Amazon

spandsp
Copyright (C) Steve Underwood
（该库采用 LGPL-2.1；测试套件与部分辅助代码采用 GPL-2，未被本应用使用）

OpenSSL
Copyright 1998-2025 The OpenSSL Project Authors
Copyright 1995-1998 Eric A. Young, Tim J. Hudson
```

---

## ⚠️ 关于 spandsp（LGPL-2.1）：分发时需要额外处理

**这一条和上面几个不一样。**

spandsp 采用 LGPL-2.1，而 BreePhone 是**静态链接**它的：baresip 的 `g722` 模块
`#include <spandsp.h>`（`modules/g722/g722.c:15`）并调用 `g722_encode_init` /
`g722_decode_init`（同文件 `:83` / `:115`）。

这一点已经在发布产物上核实过——`_g722_encode`、`_g722_decode`、
`_g722_encode_init`、`_g722_decode_init` 在 `BreePhone.app` 的可执行文件里
都是 **`T`（已定义）** 符号，也就是说 DMG 里确实含有 spandsp 编译后的代码。

LGPL-2.1 对静态链接的要求，大致是：分发二进制时，要么随附该库的完整对应源码，
要么给出书面承诺提供，并且要让接收者能够用**替换或修改过的库版本**重新链接本程序。

两条路：

1. **遵守它** —— 随分发包提供 spandsp 0.0.6 的完整源码（或书面 offer），
   以及能让使用者重链接的形式。
2. **不链接它** —— G.722 并非必需。把 `Scripts/third-party/build-baresip.sh` 里 `MODULES=`
   中的 `g722` 去掉后重新构建，产物里就不再有 spandsp 代码，这一约束自然消失。
   宽带语音可以由 `opus` 覆盖，实际通话体验差别不大。
   （同时记得同步改 `Domain/SIP/AudioCodecCatalog.swift` 的编码清单与 README 的常见问题。）

> 以上是对许可原文的转述，不构成法律意见。正式分发前请按自己的判断处理，
> 必要时咨询专业人士。

---

## 打包时怎么走

BSD-3-Clause 与 Apache-2.0 的要求主要是"保留版权声明与许可原文"。

这一步**已经自动化**了：`Scripts/package/package-app.sh` 在组装 `.app` 时会把本文件和
`licenses/` 一起拷进 `BreePhone.app/Contents/Resources/`，所以只要是正常打包出来的
DMG，声明就跟着二进制一起发出去了。发版时确认一下打包日志里有
"第三方许可已随包" 这一行即可（`RELEASING.md` 的检查清单里也列了这条）。

**换个打包方式（比如自己写脚本、或者用 Xcode 归档）时别忘了这一步** ——
许可声明漏掉不会导致任何报错，只是默默地不合规。
